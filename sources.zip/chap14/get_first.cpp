template <typename T>
T get_first(T[] a)
{
	return a[0];
}